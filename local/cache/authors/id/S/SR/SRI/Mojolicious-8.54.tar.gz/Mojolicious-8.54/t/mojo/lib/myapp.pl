use Mojolicious::Lite;

app->config(script => $0);

app->start;

=head1 SYNOPSIS

  USAGE: myapp.pl daemon

   test
  123

=cut
