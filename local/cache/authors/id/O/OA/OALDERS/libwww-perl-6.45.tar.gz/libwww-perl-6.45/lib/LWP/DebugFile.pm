package LWP::DebugFile;

our $VERSION = '6.45';

# legacy stub

1;
